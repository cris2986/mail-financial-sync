import { create } from 'zustand';
import { AppState, Transaction } from './types';

const MOCK_TRANSACTIONS: Transaction[] = [
  // October 2023
  {
    id: '1',
    title: 'Credit Card Payment',
    merchant: 'Chase Bank',
    date: 'Oct 24',
    fullDate: '2023-10-24',
    amount: 1240.00,
    type: 'expense',
    icon: 'credit_card',
    iconColorClass: 'text-orange-600',
    bgColorClass: 'bg-orange-50'
  },
  {
    id: '2',
    title: 'Utility Bill',
    merchant: 'City Water Dept',
    date: 'Oct 22',
    fullDate: '2023-10-22',
    amount: 85.40,
    type: 'expense',
    icon: 'water_drop',
    iconColorClass: 'text-blue-600',
    bgColorClass: 'bg-blue-50'
  },
  {
    id: '3',
    title: 'Direct Deposit',
    merchant: 'Employer Payroll',
    date: 'Oct 15',
    fullDate: '2023-10-15',
    amount: 2100.00,
    type: 'income',
    icon: 'account_balance',
    iconColorClass: 'text-green-600',
    bgColorClass: 'bg-green-50'
  },
  {
    id: 'income-2',
    title: 'Freelance Payment',
    merchant: 'Upwork',
    date: 'Oct 05',
    fullDate: '2023-10-05',
    amount: 2150.00,
    type: 'income',
    icon: 'work',
    iconColorClass: 'text-green-600',
    bgColorClass: 'bg-green-50'
  },
  {
    id: '4',
    title: 'Transfer Out',
    merchant: 'Savings Account',
    date: 'Oct 12',
    fullDate: '2023-10-12',
    amount: 500.00,
    type: 'expense',
    icon: 'swap_horiz',
    iconColorClass: 'text-purple-600',
    bgColorClass: 'bg-purple-50'
  },
  {
    id: '5',
    title: 'Subscription',
    merchant: 'Netflix',
    date: 'Oct 04',
    fullDate: '2023-10-04',
    amount: 15.99,
    type: 'expense',
    icon: 'receipt_long',
    iconColorClass: 'text-yellow-600',
    bgColorClass: 'bg-yellow-50'
  },
  // September 2023
  {
    id: '6',
    title: 'Rent',
    merchant: 'Landlord',
    date: 'Sep 01',
    fullDate: '2023-09-01',
    amount: 2000.00,
    type: 'expense',
    icon: 'home',
    iconColorClass: 'text-indigo-600',
    bgColorClass: 'bg-indigo-50'
  },
  {
    id: '7',
    title: 'Direct Deposit',
    merchant: 'Employer Payroll',
    date: 'Sep 15',
    fullDate: '2023-09-15',
    amount: 4150.00,
    type: 'income',
    icon: 'account_balance',
    iconColorClass: 'text-green-600',
    bgColorClass: 'bg-green-50'
  },
   // August 2023
   {
    id: '8',
    title: 'Vacation Airbnb',
    merchant: 'Airbnb',
    date: 'Aug 10',
    fullDate: '2023-08-10',
    amount: 1500.00,
    type: 'expense',
    icon: 'flight',
    iconColorClass: 'text-pink-600',
    bgColorClass: 'bg-pink-50'
  },
];

export const useAppStore = create<AppState>((set) => ({
  user: null,
  authStatus: 'idle',
  transactions: MOCK_TRANSACTIONS,
  darkMode: false,
  selectedMonth: '2023-10', // Default to October

  login: () => set({ 
    user: { 
      email: 'alex.morgan@gmail.com', 
      name: 'Alex Morgan', 
      isAuthenticated: true 
    },
    authStatus: 'authenticated'
  }),

  logout: () => set({ 
    user: null, 
    transactions: [],
    authStatus: 'unauthenticated'
  }),

  toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),

  deleteTransaction: (id) => set((state) => ({
    transactions: state.transactions.filter(t => t.id !== id)
  })),

  setSelectedMonth: (month) => set({ selectedMonth: month }),
}));